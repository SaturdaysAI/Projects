# SatAi_BicycleFriendlyPath
repository for saturdays.ai project about evaluation of bicycle-friendly paths in Madrid

##### Table of Contents  
[Preprocession of data](#Preprocession-of-data)  
   [Spacial data](#spacial-data)
   [Street photos](#Streetphotos)
   [Scene segmentation](#Segmentation)
   [Traffic data](#Traffic-data)
   
[Models](#Models)  
   

## Preprocessing of data



