import base64
import boto3
import json
import numpy as np
import io
import os
from PIL import Image

ENDPOINT_NAME = os.environ['ENDPOINT_NAME']
classes = ['cardboard', 'glass', 'metal', 'organic', 'paper', 'plastic', 'trash']
runtime= boto3.client('runtime.sagemaker')

def lambda_handler(event, context):

    body = event["body"]
    body_dec = base64.b64decode(body)

    imageStream = io.BytesIO(body_dec)
    imageFile = Image.open(imageStream)
    image_res = imageFile.resize((224,224), Image.BILINEAR)
    image_dim = np.array(image_res)
    image_dim = np.expand_dims(image_dim, axis=0)
    payload = json.dumps(image_dim.tolist())

    prediction = runtime.invoke_endpoint(EndpointName=ENDPOINT_NAME,
                                       ContentType='application/json',
                                       Body=payload)

    results = json.loads(prediction['Body'].read().decode())['predictions'][0]
    
    classification = classes[np.argmax(results)]
    probability = str(round(np.amax(results)*100, 2))

    print('Class: ' + classification + ' Probability' + probability + ' %')

    return {'class': classification, 'probability': probability}